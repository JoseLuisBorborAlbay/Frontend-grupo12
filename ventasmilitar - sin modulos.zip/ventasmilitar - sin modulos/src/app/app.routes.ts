import { RouterModule, Routes } from '@angular/router';
import { CuerpoComponent } from './Componentes/cuerpo/cuerpo.component';
import { NgModule } from '@angular/core';
import { LoginComponent } from './Componentes/login/login.component';
import { RegistroComponent } from './Componentes/registro/registro.component';
import { ProductosComponent } from './Componentes/productos/productos.component';
import { CatalogoComponent } from './Componentes/catalogo/catalogo.component';
import { RevistaComponent } from './Componentes/revista/revista.component';
import { EmpresaComponent } from './Componentes/empresa/empresa.component';
import { RegistroProveedorComponent } from './Componentes/registro-proveedor/registro-proveedor.component';

export const routes: Routes = [

    { path: '', redirectTo: 'cuerpo', pathMatch: 'full' },
    { path: 'cuerpo', component: CuerpoComponent },
    { path: 'login', component: LoginComponent },
    { path: 'registro', component: RegistroComponent },
    { path: 'producto', component: ProductosComponent },
    { path: 'catalogo', component: CatalogoComponent },
    { path: 'revista', component: RevistaComponent },
    { path: 'empresa', component: EmpresaComponent },
    { path: 'registroProveedor', component: RegistroProveedorComponent },
    { path: '**', redirectTo: 'cuerpo', pathMatch: 'full' },


];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }

