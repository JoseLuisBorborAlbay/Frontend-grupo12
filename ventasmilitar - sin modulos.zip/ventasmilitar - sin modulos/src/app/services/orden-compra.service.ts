import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { OrdenCompra } from '../Interface/ordenCompra';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrdenCompraService {
  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/OrdenCompra/';

  constructor(private http: HttpClient) { }

  createOrder(order: any): Observable<any> {
    return this.http.post<any>(`${this.myAppUrl}${this.myApiUrl}`, order);
  }
}
