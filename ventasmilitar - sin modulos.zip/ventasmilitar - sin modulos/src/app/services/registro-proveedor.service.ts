import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RegistroProveedor } from '../Interface/registroProveedor';

@Injectable({
  providedIn: 'root'
})
export class RegistroProveedorService {

  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Proveedor/';

  constructor(private http: HttpClient) { }

  addUsuario(usuario:RegistroProveedor): Observable<number>{
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`,usuario);
  }
  getRegistro(): Observable<RegistroProveedor[]> {
    return this.http.get<RegistroProveedor[]>(`${this.myAppUrl}${this.myApiUrl}`);
   
  }

  getRegistroID(id: number): Observable<RegistroProveedor>{
    return this.http.get<RegistroProveedor>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  eliminarRegistro(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  modificarRegistro(usuario: RegistroProveedor): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${usuario.proveedorId}`,usuario);
  }
}
