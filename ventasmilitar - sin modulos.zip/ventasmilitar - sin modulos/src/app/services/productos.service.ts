import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Producto } from '../Interface/producto';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  private myAppUrl: string = environment.endpoint;
  private myApiUrl: string = 'api/Producto/';

  constructor(private http: HttpClient) { }

  addUsuario(usuario:Producto): Observable<number>{
    return this.http.post<number>(`${this.myAppUrl}${this.myApiUrl}`,usuario);
  }
  getRegistro(): Observable<Producto[]> {
    return this.http.get<Producto[]>(`${this.myAppUrl}${this.myApiUrl}`);
   
  }

  getRegistroID(id: number): Observable<Producto>{
    return this.http.get<Producto>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  eliminarRegistro(id: number): Observable<void>{
    return this.http.delete<void>(`${this.myAppUrl}${this.myApiUrl}${id}`);
  }
  modificarRegistro(usuario: Producto): Observable<number>{
    return this.http.put<number>(`${this.myAppUrl}${this.myApiUrl}${usuario.productoId}`,usuario);
  }
}
