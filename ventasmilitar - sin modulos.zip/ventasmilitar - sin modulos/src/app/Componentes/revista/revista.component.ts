import { Component } from '@angular/core';

@Component({
  selector: 'app-revista',
  standalone: true,
  imports: [],
  templateUrl: './revista.component.html',
  styleUrl: './revista.component.css'
})
export class RevistaComponent {

}
