import { Component } from '@angular/core';
import { RegistroProveedor } from '../../Interface/registroProveedor';
import { RegistroProveedorService } from '../../services/registro-proveedor.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';

import { CommonModule } from '@angular/common';
import { ProductosService } from '../../services/productos.service';
import { Producto } from '../../Interface/producto';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,RouterLink,RouterOutlet,HttpClientModule],
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.css'
})
export class ProductosComponent {
  imagenPreview: string | ArrayBuffer | null = null;
  imagenFile: File | null = null;
  proveedor: RegistroProveedor[]=[] ;
  prod : Producto[]= [];
  form: FormGroup;
  editForm: FormGroup;
  isEditTreatmentModalOpen = false;
  selectedRegistro: Producto | null = null;
  id!:number;
  alertMessage: string | null = null;
  alertClass: string = 'alert-success';

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.imagenFile = input.files[0];
      const reader = new FileReader();
      reader.onload = e => this.imagenPreview = reader.result;
      reader.readAsDataURL(this.imagenFile);
    }
  }

  constructor(  
    private _usuarioService: RegistroProveedorService,
    private _productoService: ProductosService,
  
    private router: Router,
    private fb: FormBuilder,
    private aRoute: ActivatedRoute,
    
  ) {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
    this.form = this.fb.group({
   
      proveedorId: ['', Validators.required],
      nombre: ['', Validators.required],
      imagen: [null, Validators.required],
      descripcion: ['', Validators.required],
      cantidad: ['', Validators.required],
      precio: ['', Validators.required],

    });
    this.editForm = this.fb.group({
      proveedorId: ['', Validators.required],
      nombre: ['', Validators.required],
      imagen: [null, Validators.required],
      descripcion: ['', Validators.required],
      cantidad: ['', Validators.required],
      precio: ['', Validators.required],
    });
  }

  ngOnInit(): void {

    this.consultarProveedor();
    this.consultarProducto();
  
  }
  consultarProveedor(): void {
    this._usuarioService.getRegistro().subscribe({
      next: data => {
        console.log('Datos recibidos:', data); 
        this.proveedor = data;
      },
      error: error => {
        console.log('Obtención de historias clínicas completa');
     
      },
      complete: () => {
        console.info('Obtención de historias clínicas completa');
      }
    });
  }
  consultarProducto(): void {
    this._productoService.getRegistro().subscribe({
      next: data => {
        console.log('Datos recibidos:', data); 
        this.prod = data;
      },
      error: error => {
     //alert("error");
        //this.showAlert('Ocurrió un error al obtener las historias clínicas', 'alert-danger');
      },
      complete: () => {
        console.info('Obtención de historias clínicas completa');
      }
    });
  }


  agregarRegistro(){
    const usuario: Producto = {
      proveedorId: this.form.value.proveedorId,
      nombre: this.form.value.nombre,
      imagen: this.imagenPreview as string,    
      descripcion: this.form.value.descripcion,
      cantidad: this.form.value.cantidad,
      precio: this.form.value.precio,
      
    }
    this._productoService.addUsuario(usuario).subscribe({
      next: data => {
        console.log(data);       
      },
      error: error => {
        //this.showAlert('Ocurrió un error al agregar', 'alert-danger');
      },
      complete: () => {
        console.info('Agregar libro completa');
        alert("Se agrego correctamente");
      }
    });
    this.form.reset();
    this.imagenPreview = null;
  }

  trackByFn(index: number, item: Producto): number {
    return item.productoId ?? -1; // Usa -1 si productoId es undefined
  }

  closeModal(modalId: string): void {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
      modalElement.style.display = 'none';
    }
  }

  openEditproModal(registro: Producto) {
    this.selectedRegistro = registro;
    if (registro.productoId !== undefined) {
      this.obtenerDatosModificar(registro.productoId);
      this.isEditTreatmentModalOpen = true;
    } else {
     // alert('procedimiento seleccionado no tiene un ID válido.');
    }
  }

  
  obtenerDatosModificar(id: number) {
    this._productoService.getRegistroID(id).subscribe({
      next: data => {
        console.log(data);
        this.editForm.patchValue({
          proveedorId: data.proveedorId,
          nombre: data.nombre,
          imagen: data.imagen,
          descripcion: data.descripcion,
          cantidad: data.cantidad,
          precio: data.precio,
        });
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de datos para modificar completa');
      }
    });
  }

  modificarUsuario(){
    const usuario: Producto = {
      productoId: this.id,
      proveedorId: this.form.value.proveedorId,
      nombre: this.form.value.nombre,    
      imagen: this.form.value.imagen,
      descripcion: this.form.value.descripcion,
      cantidad: this.form.value.cantidad,
      precio: this.form.value.precio,
      
    }
    
    this._productoService.modificarRegistro(usuario).subscribe({
      next: data => {
        console.log(data);
        this.showSuccessModal('addSuccessModal');
        
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Modificacion de libro completa');
      }
    });
    this.form.reset();
    
  }

  modificarRegistroU() {
    if (!this.selectedRegistro || !this.selectedRegistro.productoId) {
      alert('No se ha seleccionado un procedimiento válido para modificar.');
      return;
    }

    const registro: Producto = {
      productoId: this.selectedRegistro.productoId,
      proveedorId: this.editForm.value.proveedorId,
      nombre: this.editForm.value.nombre,
      imagen: this.editForm.value.imagen,
      descripcion: this.editForm.value.descripcion,
      cantidad: this.editForm.value.cantidad,
      precio: this.editForm.value.precio,
    };

    this._productoService.modificarRegistro({
      ...registro,
      proveedorId: this.selectedRegistro.productoId
    }).subscribe({
      next: data => {
        console.log('procedimiento modificado:', data);
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Modificación de procedimiento completa');
        this.showSuccessModal('modifySuccessModal');
        this.closeEditproModal();
        this.obtenerRegistro();
      }
    });
    this.editForm.reset();
    this.closeEditproModal();
  }
  private showAlert(message: string, alertClass: string) {
    this.alertMessage = message;
    this.alertClass = alertClass;
    setTimeout(() => {
      this.alertMessage = null;
    }, 3000);
  }
  private showSuccessModal(modalId: string): void {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
      modalElement.style.display = 'block';
    }
  }

  closeEditproModal() {
    this.isEditTreatmentModalOpen = false;
  }
  obtenerRegistro(): void {
    this._productoService.getRegistro().subscribe({
      next: data => {
        console.log(data);
        this.prod = data;
      },
      error: error => {
        this.showAlert('Ocurrió un error ', 'alert-danger');
      },
      complete: () => {
        console.info('Obtención de libros completa');
      }
    });
  }

  eliminarUsuario(id?: number ){

    if (id === undefined) {
      alert('El ID indefinido');
      return;
    }
    this._productoService.eliminarRegistro(id).subscribe({
      next: data => {
        console.log('Libro eliminado:', data);
        this.showSuccessModal('deleteSuccessModal');
        this.obtenerRegistro();
      },
      error: error => {
        this.showAlert('Ocurrió un error ', 'alert-danger');
      },
      complete: () => {
        console.info('Eliminacion de libro completa');
        
      }
    });
  }
}


