import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { RegistroService } from '../../services/registro.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterLink,  RouterOutlet, ReactiveFormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private registroService: RegistroService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      correo: ['', [Validators.required, Validators.email]],
      contrasenia: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { correo, contrasenia } = this.loginForm.value;
      this.registroService.autenticarUsuario(correo, contrasenia).subscribe({
        next: usuario => {
          if (usuario) {
            // Guardar el usuario en el almacenamiento local
            localStorage.setItem('user', JSON.stringify(usuario));
            console.log('Usuario autenticado:', usuario);
            alert("Bienvenido al sistema");
            this.router.navigate(['/home']); // Redirigir a la página principal después del inicio de sesión
          } else {
            console.log('Usuario o contraseña incorrectos');
            alert("Usuario o contraseña incorrectos");
          }
        },
        error: error => {
          console.error('Error al autenticar usuario:', error);
          alert("Error al autenticar usuario");
        }
      });
    }
  }
}
