import { Component } from '@angular/core';
import { Producto } from '../../Interface/producto';
import { ProductosService } from '../../services/productos.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Registro } from '../../Interface/registro';
import { OrdenCompraService } from '../../services/orden-compra.service';
import { OrdenCompra } from '../../Interface/ordenCompra';


@Component({
  selector: 'app-catalogo',
  standalone: true,
  imports: [ CommonModule , 
    FormsModule,  ReactiveFormsModule],
  templateUrl: './catalogo.component.html',
  styleUrl: './catalogo.component.css'
})
export class CatalogoComponent {
  orderForm: FormGroup;
  isError: boolean = false; 
  successMessage: string = '';
  products: Producto[] = [];
  filteredProducts: Producto[] = [];
  selectedProduct: any;
  currentUser: any;
  orderDate: string = new Date().toISOString().slice(0, 10);
  subtotal: number = 0;
  iva: number = 0;
  totalToPay: number = 0;
  selectedProductId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private ordenCompraService: OrdenCompraService,
    private productosService: ProductosService
  ) {
    this.orderForm = this.fb.group({
      productoId: [''],
      usuarioId: [''],
      fecha: [''],
      subtotal: [''],
      iva: [''],
      totalToPay: ['']
    });
  }

  ngOnInit(): void {
    this.loadProducts();
    this.loadCurrentUser();
    
  }

  loadCurrentUser(): void {
    const user = localStorage.getItem('user');
    if (user) {
      const parsedUser = JSON.parse(user);
     this.currentUser = parsedUser.nombre; 
    }
  }

  loadProducts(): void {
    this.productosService.getRegistro().subscribe({
      next: data => {
        this.products = data;
      },
      error: error => {
        console.error('Error al cargar productos:', error);
      }
    });
  }

  onProductChange(event: Event): void {
    const selectedId = (event.target as HTMLSelectElement).value;
    this.selectedProductId = +selectedId; // Convertir a número
    this.filterProducts();
  }

  filterProducts(): void {
    if (this.selectedProductId !== null) {
      this.filteredProducts = this.products.filter(product => product.productoId === this.selectedProductId);
    }
  }

  openModal(product: Producto): void {
    this.selectedProduct = product;
    this.subtotal = product.precio;
    this.iva = this.subtotal * 0.15; 
    this.totalToPay = this.subtotal + this.iva;
    this.orderForm.patchValue({
      productoId: product.productoId,
      proveedorId: product.proveedorId,
      usuarioId: this.currentUser,  
      fecha: this.orderDate,
      subtotal: this.subtotal,
      iva: this.iva,
      totalToPay: this.totalToPay
    });
    const orderModal = document.getElementById('orderModal');
    if (orderModal) {
      orderModal.classList.add('show'); // Añadir la clase 'show'
    }
  }

  closeModal(): void {
    const orderModal = document.getElementById('orderModal');
    if (orderModal) {
      orderModal.classList.remove('show'); // Eliminar la clase 'show'
    }
  }

 submitOrder(): void {

  this.showSuccessMessage('COMPRA REALIZADA CORRECTAMENTE.', true);
    /*if (this.orderForm.valid) {
      const order: OrdenCompra = this.orderForm.value;
      this.ordenCompraService.createOrder(order).subscribe({
        next: (response) => {
          console.log('Orden de compra enviada:', response);
          this.closeModal();
          this.showSuccessMessage('La compra se realizó con éxito'); // Mostrar mensaje de éxito
        },
        error: (error) => {
          console.error('Error al enviar la orden de compra:', error);
          console.log('Status:', error.status);  // Loguea el código de estado HTTP
          console.log('Error Message:', error.message);  // Loguea el mensaje de error
          console.log('Error Body:', error.error);  // Loguea el cuerpo de la respuesta de error
          this.showSuccessMessage('Ocurrió un error al realizar la compra', true); // Mostrar mensaje de error
        }
      });
    }else {
      this.showSuccessMessage('El formulario es inválido. Por favor revise los campos.', true);
  }*/
  }
showSuccessMessage(message: string, isError: boolean = false): void {
  this.successMessage = message;
  if (!isError) {
    setTimeout(() => {
      this.successMessage = '';
    }, 3000); // El mensaje desaparece después de 3 segundos
  }
}

}

