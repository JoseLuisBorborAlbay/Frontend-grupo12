import { Component } from '@angular/core';

@Component({
  selector: 'app-empresa',
  standalone: true,
  imports: [],
  templateUrl: './empresa.component.html',
  styleUrl: './empresa.component.css'
})
export class EmpresaComponent {

}
