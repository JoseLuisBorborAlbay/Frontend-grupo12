import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slideshow',
  templateUrl: './slideshow.component.html',
  styleUrls: ['./slideshow.component.css'],
  standalone: true
})
export class SlideshowComponent implements OnInit{
  images: string[] = [
    'assets/img/centro.jpg',
    'assets/img/cambio.jpg'
  ];
  currentImageIndex: number = 0;

  ngOnInit() {
    this.startSlideshow();
  }

  startSlideshow() {
    setInterval(() => {
      this.currentImageIndex = (this.currentImageIndex + 1) % this.images.length;
    }, 3000); // Cambia la imagen cada 3 segundos
  }




}
