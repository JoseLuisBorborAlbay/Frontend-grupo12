import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RegistroService } from '../../services/registro.service';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { Registro } from '../../Interface/registro';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [ReactiveFormsModule,RouterLink,RouterOutlet, CommonModule],
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.css'
})
export class RegistroComponent {
  editForm: FormGroup;
  form: FormGroup;
  id!:number;
  listaRegistro: Registro []=[];
  alertMessage: string | null = null;
  alertClass: string = 'alert-success';
  selectedRegistro: Registro | null = null;
  isViewDetailModalOpen = false;
  isEditTreatmentModalOpen = false;

  openViewDetailModal(usuario: any) {
    this.selectedRegistro = usuario;
    this.isViewDetailModalOpen = true;
  }

  openEditproModal(registro: Registro) {
    this.selectedRegistro = registro;
    if (registro.usuarioId !== undefined) {
      this.obtenerDatosModificar(registro.usuarioId);
      this.isEditTreatmentModalOpen = true;
    } else {
     // alert('procedimiento seleccionado no tiene un ID válido.');
    }
  }



  closeEditproModal() {
    this.isEditTreatmentModalOpen = false;
  }
  closeViewDetailModal() {
    this.isViewDetailModalOpen = false;
  }
  constructor(  private _usuarioService: RegistroService,
  
    private router: Router,
    private fb: FormBuilder,
    private aRoute: ActivatedRoute,

  ) 
    {
    this.id = Number(this.aRoute.snapshot.paramMap.get('id'));
    this.form = this.fb.group({
   
      nombre: ['', Validators.required],
      correo: ['', Validators.required],
      contrasenia: ['', Validators.required],
      direccion: ['', Validators.required],
    });
    this.editForm = this.fb.group({
      nombre: ['', Validators.required],
      correo: ['', Validators.required],
      contrasenia: ['', Validators.required],
      direccion: ['', Validators.required],
    });
  }
  
   
  ngOnInit(): void {
    this.obtenerRegistro();
   

   }
  agregarRegistro(){
    const usuario: Registro = {
      nombre: this.form.value.nombre,
      correo: this.form.value.correo,    
      contrasenia: this.form.value.contrasenia,
      direccion: this.form.value.direccion,
      
    }
    this._usuarioService.addUsuario(usuario).subscribe({
      next: data => {
        console.log(data);       
      },
      error: error => {
        this.showAlert('Ocurrió un error al agregar', 'alert-danger');
      },
      complete: () => {
        console.info('Agregar libro completa');
        alert("Se agrego correctamente");
      }
    });
    this.form.reset();
  }


  obtenerRegistro(): void {
    this._usuarioService.getRegistro().subscribe({
      next: data => {
        console.log(data);
        this.listaRegistro = data;
      },
      error: error => {
        this.showAlert('Ocurrió un error al obtener las procedimiento', 'alert-danger');
      },
      complete: () => {
        console.info('Obtención de libros completa');
      }
    });
  }

  eliminarUsuario(id?: number ){

    if (id === undefined) {
      alert('El ID del libro es indefinido');
      return;
    }
    this._usuarioService.eliminarRegistro(id).subscribe({
      next: data => {
        console.log('Libro eliminado:', data);
        this.showSuccessModal('deleteSuccessModal');
        this.obtenerRegistro();
      },
      error: error => {
        this.showAlert('Ocurrió un error al obtener las procedimiento', 'alert-danger');
      },
      complete: () => {
        console.info('Eliminacion de libro completa');
        
      }
    });
  }

  modificarUsuario(){

    const usuario: Registro = {
      usuarioId: this.id,
      nombre: this.form.value.nombre,
      correo: this.form.value.correo,    
      contrasenia: this.form.value.contrasenia,
      direccion: this.form.value.direccion,
      
    }
    
    this._usuarioService.modificarRegistro(usuario).subscribe({
      next: data => {
        console.log(data);
        this.showSuccessModal('addSuccessModal');
        
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Modificacion de libro completa');
      }
    });
    this.form.reset();
    
  }




  obtenerDatosModificar(id: number) {
    this._usuarioService.getRegistroID(id).subscribe({
      next: data => {
        console.log(data);
        this.editForm.patchValue({
          nombre: data.nombre,
          correo: data.correo,
          contrasenia: data.contrasenia,
          direccion: data.direccion,
        });
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Obtención de datos para modificar completa');
      }
    });
  }

  modificarRegistroU() {
    if (!this.selectedRegistro || !this.selectedRegistro.usuarioId) {
      alert('No se ha seleccionado un procedimiento válido para modificar.');
      return;
    }

    const registro: Registro = {
      usuarioId: this.selectedRegistro.usuarioId,
      nombre: this.editForm.value.nombre,
      correo: this.editForm.value.correo,
      contrasenia: this.editForm.value.contrasenia,
      direccion: this.editForm.value.direccion,
    };

    this._usuarioService.modificarRegistro({
      ...registro,
      usuarioId: this.selectedRegistro.usuarioId
    }).subscribe({
      next: data => {
        console.log('procedimiento modificado:', data);
      },
      error: error => {
        alert("Ocurrió un error");
      },
      complete: () => {
        console.info('Modificación de procedimiento completa');
        this.showSuccessModal('modifySuccessModal');
        this.closeEditproModal();
        this.obtenerRegistro();
      }
    });
    this.editForm.reset();
    this.closeEditproModal();
  }
  private showAlert(message: string, alertClass: string) {
    this.alertMessage = message;
    this.alertClass = alertClass;
    setTimeout(() => {
      this.alertMessage = null;
    }, 3000);
  }
  private showSuccessModal(modalId: string): void {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
      modalElement.style.display = 'block';
    }
  }

  closeModal(modalId: string): void {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
      modalElement.style.display = 'none';
    }
  }

}
