import { Component } from '@angular/core';

@Component({
  selector: 'app-footer', 
  standalone: true,// Asegúrate de que el selector sea único y esté bien definido
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  // Contenido del componente
}

