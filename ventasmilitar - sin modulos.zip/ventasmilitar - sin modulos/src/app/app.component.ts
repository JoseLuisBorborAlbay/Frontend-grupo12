import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CabeceraComponent } from './Componentes/cabecera/cabecera.component';
import { FooterComponent } from './Componentes/footer/footer.component';
import { CuerpoComponent } from './Componentes/cuerpo/cuerpo.component';
import { SlideshowComponent } from './Componentes/slideshow/slideshow.component';




@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css'],
    imports: [RouterOutlet, CabeceraComponent, FooterComponent, CuerpoComponent, SlideshowComponent]
})

export class AppComponent {
  title = 'ventasmilitar';
}


