import { Producto } from "./producto";
import { Registro } from "./registro";
import { RegistroProveedor } from "./registroProveedor";

export interface OrdenCompra{
    ordenCompraoId? : number,
    productoId: number,
    proveedorId : number,
    usuarioId:  number,
    fecha: Date,
    total: number,
    subtotal: number,
    totalApagar: number,
    registroProveedor? : RegistroProveedor,
    producto? : Producto,
    registro? : Registro
}