import { RegistroProveedor } from "./registroProveedor";

export interface Producto{ 
    productoId? : number,
    proveedorId : number,
    nombre: string,
    imagen: string,
    descripcion: string,
    cantidad: number,
    precio: number,
    registroProveedor? : RegistroProveedor

}