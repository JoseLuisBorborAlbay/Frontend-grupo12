export interface Registro{ 
    usuarioId? : number,
    nombre : string,
    correo : string,
    contrasenia : string,
    direccion : string, 
}


