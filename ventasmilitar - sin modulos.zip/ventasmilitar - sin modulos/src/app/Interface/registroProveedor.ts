export interface RegistroProveedor{ 
    proveedorId? : number,
    nombre : string,
    direccion : string, 
    telefono : string, 
    correo : string,

    
}